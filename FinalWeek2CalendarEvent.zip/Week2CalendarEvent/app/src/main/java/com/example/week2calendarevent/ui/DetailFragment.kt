package com.example.week2calendarevent.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.week2calendarevent.R
import com.example.week2calendarevent.databinding.FragmentDetailBinding
import com.example.week2calendarevent.model.CustomEvent
import com.example.week2calendarevent.ui.add.CreateEventFragment

class DetailFragment : Fragment() {

    private val binding by lazy {
        FragmentDetailBinding.inflate(layoutInflater)
    }

    private var newCustomEvent: CustomEvent? = null
    private var newAction: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            newCustomEvent = it.getSerializable(CreateEventFragment.EVENT_DATA) as? CustomEvent
            newAction = it.getString("ACTION")
        }

        binding.titleTextView.text = newCustomEvent?.title
        binding.dateTextView.text = newCustomEvent?.date
        binding.descTextView.text = newCustomEvent?.description
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        arguments?.let {
            newCustomEvent = it.getSerializable(CreateEventFragment.EVENT_DATA) as? CustomEvent
        }

        binding.editEventBtn.setOnClickListener{
            findNavController().navigate(R.id.action_DetailFragment_to_CreateEventFragment, bundleOf(Pair(
                CreateEventFragment.EVENT_DATA, newCustomEvent), Pair("ACTION", "PUT")))
        }

        binding.deleteEventBtn.setOnClickListener{
            findNavController().navigate(R.id.action_DetailFragment_to_ListOfRemindersFragment, bundleOf(Pair(
                CreateEventFragment.EVENT_DATA, newCustomEvent), Pair("ACTION", "DELETE")))
        }

        // Inflate the layout for this fragment
        return binding.root
    }
  }
