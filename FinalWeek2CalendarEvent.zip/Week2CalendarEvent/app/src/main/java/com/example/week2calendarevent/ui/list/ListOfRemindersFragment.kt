package com.example.week2calendarevent.ui.list

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.week2calendarevent.R
import com.example.week2calendarevent.adapter.ClickHandler
import com.example.week2calendarevent.adapter.EventAdapter
import com.example.week2calendarevent.databinding.FragmentListOfRemindersBinding
import com.example.week2calendarevent.model.CustomEvent
import com.example.week2calendarevent.ui.add.CreateEventFragment

class ListOfRemindersFragment : Fragment(), ClickHandler {

    private val binding by lazy {
        FragmentListOfRemindersBinding.inflate(layoutInflater)
    }

    private val eventAdapter by lazy {
        EventAdapter(this) { customEvent ->
            findNavController().navigate(
                R.id.action_listOfRemindersFragment_to_detailsFragment,
                bundleOf(Pair(CreateEventFragment.EVENT_DATA, customEvent))
            )
        }
    }

    private var newEvent: CustomEvent? = null
    private var newAction: String? = null
//    private lateinit var mEventViewModel: EventViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            newEvent = it.getSerializable(CreateEventFragment.EVENT_DATA) as? CustomEvent
            newAction = it.getString("ACTION")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding.reminderList.apply {
            layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
            adapter = eventAdapter
        }

//        mEventViewModel = ViewModelProvider(this).get(EventViewModel::class.java)
//        mEventViewModel.readAllData.observe(viewLifecycleOwner, Observer { customEvent ->
//            eventAdapter.updateCustomEventList()
//        })

        binding.addEventBtn.setOnClickListener{
            findNavController().navigate(R.id.action_ListOfRemindersFragment_to_CreateEventFragment)
        }

        binding.homeBtn.setOnClickListener{
            findNavController().navigate(R.id.action_ListOfRemindersFragment_to_HomeFragment)
        }

        return binding.root
    }

    override fun onResume() {
        super.onResume()

        newEvent?.let {
            eventAdapter.updateCustomEventList(it, "ACTION")
            newEvent = null
            arguments = null
        }
    }

    override fun onCustomEventCLick(customEvent: CustomEvent) {
        findNavController().navigate(
            R.id.action_listOfRemindersFragment_to_detailsFragment,
            bundleOf(Pair(CreateEventFragment.EVENT_DATA, customEvent))
        )

    }

}