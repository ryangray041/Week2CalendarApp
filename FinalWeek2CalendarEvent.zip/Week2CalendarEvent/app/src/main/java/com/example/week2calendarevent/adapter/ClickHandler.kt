package com.example.week2calendarevent.adapter

import com.example.week2calendarevent.model.CustomEvent

interface ClickHandler {

    fun onCustomEventCLick(customEvent: CustomEvent)

}