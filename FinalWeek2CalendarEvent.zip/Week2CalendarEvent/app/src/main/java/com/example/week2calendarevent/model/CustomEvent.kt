package com.example.week2calendarevent.model

import java.io.Serializable

data class CustomEvent (
    val title: String,
    val date: String,
    val description: String
   // val id: Int? = eventList.size
) : Serializable
