package com.example.week2calendarevent.ui.add

import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.week2calendarevent.R
import com.example.week2calendarevent.data.Event
import com.example.week2calendarevent.data.EventViewModel
import com.example.week2calendarevent.databinding.FragmentCreateEventBinding
import com.example.week2calendarevent.model.CustomEvent
import java.text.SimpleDateFormat

class CreateEventFragment : Fragment() {

    private lateinit var mEventViewModel: EventViewModel

    private val binding by lazy {
        FragmentCreateEventBinding.inflate(layoutInflater)
    }

    private var newEvent: CustomEvent? = null
    private var newAction: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            newEvent = it.getSerializable(EVENT_DATA) as? CustomEvent
            newAction = it.getString("ACTION")
        }

        when(newAction){
            "PUT" -> {
                binding.titleEditText.setText(newEvent?.title)
                binding.descEditText.setText(newEvent?.description)
            }
        }

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mEventViewModel = ViewModelProvider(this).get(EventViewModel::class.java)

        val dateFormat = SimpleDateFormat("MM/dd/yyyy")
        var date: String
        binding.calendarView.setOnDateChangeListener {view, year, month, dayOfMonth ->
            date = "${month+1}/$dayOfMonth/$year"
        }.let {
            date = dateFormat.format(binding.calendarView.date)
        }

        binding.titleEditText.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                // no-op
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                binding.createEventBtn2.isEnabled = p0?.isNotEmpty() ?: false
            }

            override fun afterTextChanged(p0: Editable?) {
                // no-op
            }
        })

        binding.createEventBtn2.setOnClickListener{
            val title = binding.titleEditText.text.toString()
            val desc = binding.descEditText.text.toString()

            insertDataToDatabase()

            CustomEvent(title, date, desc).also {
                findNavController().navigate(R.id.action_CreateEventFragment_to_ListOfRemindersFragment, bundleOf(
                    Pair(EVENT_DATA, it),
                    Pair("ACTION", newAction)
                ))
            }
        }

        return binding.root
    }

    private fun insertDataToDatabase(){
        val title = binding.titleEditText.text.toString()
        val date = binding.calendarView.date.toString()
        val desc = binding.descEditText.text.toString()

        if(inputCheck(title, date, desc)){
            //Create Event Object
            val event = Event(0,title, date, desc)
            //Add data to database
            mEventViewModel.addEvent(event)
        }
    }

    private fun inputCheck(title: String, date: String, desc: String): Boolean{
        return !(TextUtils.isEmpty(title) && TextUtils.isEmpty(date) && TextUtils.isEmpty(desc))
    }

    companion object{
        const val EVENT_DATA = "EVENT_DATA"
    }

}


