package com.example.week2calendarevent.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.week2calendarevent.databinding.FragmentContentsReminderBinding
import com.example.week2calendarevent.model.CustomEvent

    class EventAdapter(
        private val onCustomEventCLickListener: ClickHandler,
        private val eventList: MutableList<CustomEvent> = Singleton.eventList,
        private val onCustomEventClickHighOrderFunction: (CustomEvent) -> Unit
    ) : RecyclerView.Adapter<CustomEventViewHolder>() {

        fun updateCustomEventList(customEvent: CustomEvent, action: String){
            when(action){
                "PUT" -> eventList[eventList.indexOf(customEvent)+ 1] = customEvent
                "DELETE" -> eventList.remove(customEvent)
                else ->
                    eventList.add(customEvent)
            }
            notifyItemInserted(eventList.indexOf(customEvent))
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomEventViewHolder {
            val from = LayoutInflater.from(parent.context)
            val binding = FragmentContentsReminderBinding.inflate(from, parent, false)
            return CustomEventViewHolder(binding)
        }

        override fun onBindViewHolder(holder: CustomEventViewHolder, position: Int) {
            holder.bindCustomEvent(onCustomEventCLickListener, eventList[position], onCustomEventClickHighOrderFunction)
        }

        override fun getItemCount(): Int {
            return eventList.size
        }
    }

    class CustomEventViewHolder(
        private val reminderContentsBinding: FragmentContentsReminderBinding
    ) : RecyclerView.ViewHolder(reminderContentsBinding.root) {

        fun bindCustomEvent(
            onCustomEventCLickListener: ClickHandler,
            customEvent: CustomEvent,
            onCustomEventClickHighOrderFunction: (CustomEvent) -> Unit
        ){
            reminderContentsBinding.eventTitle.text = customEvent.title
            reminderContentsBinding.eventDate.text = customEvent.date
            reminderContentsBinding.eventDesc.text = customEvent.description

            itemView.setOnClickListener{
                onCustomEventClickHighOrderFunction(customEvent)
            }

        }

    }

