package com.example.week2calendarevent.data

import androidx.lifecycle.LiveData

class EventRepository(private val eventDAO: EventDAO) {

    val readAllData: LiveData<List<Event>> = eventDAO.readAllData()

    suspend fun addEvent(event: Event){
        eventDAO.addEvent(event)
    }

}